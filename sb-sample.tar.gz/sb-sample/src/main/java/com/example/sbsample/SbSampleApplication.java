package com.example.sbsample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class SbSampleApplication {
    
    public static void main(String[] args) {
	SpringApplication.run(SbSampleApplication.class, args);
    }

    @RequestMapping("/")
    String hello() {
	return "hello world";
    }
}
